Instructions:
1. Install Python 3.11

2. Install the following modules in the cmd:
	- Pandas: 	pip install pandas
	- matplotlib: 	pip install matplotlib

3. In line 8 of the code, change the value of file with the
	  absolute file path of the csv file

4. If using VSCODE, make sure:
	- view--> command palette --> Python: Select Interpreter --> Python 3.11
   If using another IDE: make sure the correct Python version is selected (3.11)
	ex: use IDLE 3.11



